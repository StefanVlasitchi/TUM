import socket
import threading

HOST = "127.0.0.1"
PORT = 5050

# Cream un server socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

# Lista pentru a memora toți clienții conectați
clients = []


def broadcast_message(message, sender_socket):
    for client_socket in clients:
        if client_socket != sender_socket:
            client_socket.send(message.encode("utf-8"))


def handle_client(client_socket):
    try:
        while True:
            message = client_socket.recv(1024).decode("utf-8")
            if not message:
                break
            print(f"Mesaj primit de la un client: {message}")
            broadcast_message(message, client_socket)
    except ConnectionResetError:
        pass
    finally:
        # Închidem conexiunea și îndepărtăm clientul din lista
        clients.remove(client_socket)
        client_socket.close()


def start_server():
    print("Serverul este pornit și ascultă pe portul", PORT)
    while True:
        client_socket, client_address = server.accept()
        print(f"Conexiune nouă de la {client_address}")
        clients.append(client_socket)
        # Pornim un fir de execuție separat pentru fiecare client
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()


if __name__ == "__main__":
    start_server()
