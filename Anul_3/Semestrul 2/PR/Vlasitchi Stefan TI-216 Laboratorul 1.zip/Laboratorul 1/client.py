import socket
import threading

HOST = "127.0.0.1"
PORT = 5050
ADDR = (HOST, PORT)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


def receive_messages():
    while True:
        try:
            message = client.recv(1024).decode("utf-8")
            print("Mesaj primit:", message)
            print("Introduceti mesajul:")
        except:
            client.close()
            break


def send_messages():
    while True:
        try:
            print("Introduceti mesajul:")
            message = input()
            client.send(message.encode("utf-8"))
        except:
            break


if __name__ == "__main__":
    try:
        client.connect(ADDR)
        send_thread = threading.Thread(target=send_messages)
        send_thread.start()
        receive_thread = threading.Thread(target=receive_messages)
        receive_thread.start()
    except:
        print("Serverul este deconectat")
