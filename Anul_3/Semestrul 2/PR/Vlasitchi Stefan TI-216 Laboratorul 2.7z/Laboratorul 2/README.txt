1.Se ruleaza fisierul server.py in "CMD": run server.py
2.Se ruleaza n fisiere client.py in "CMD":run client.py
3.Se asteapta conexiunea dintre server-client iar dupa primirea mesajului de confirmare aplicatia poate rula 
